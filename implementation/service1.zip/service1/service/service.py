import uuid

from nameko.rpc import rpc
from nameko.events import EventDispatcher
from nameko_sqlalchemy import DatabaseSession
from nameko_redis import Redis

from service.exceptions import NotFound
from service.models import DeclarativeBase, Pessoa, Divida
from service.schemas import PessoaSchema, DividaSchema

class Service:
    name = 'service'

    db = DatabaseSession(DeclarativeBase)
    event_dispatcher = EventDispatcher()

    @rpc
    def get_pessoa(self, pessoa_id):
        pessoa = self.db.query(Pessoa)(pessoa_id)

        if not pessoa:
            raise Notfound('Pessoa com id {} não encontrada'.format(pessoa_id))
        
        return PessoaSchema().dump(pessoa).data
    
    @rpc
    def create_pessoa(self, pessoas):
        pessoa = Pessoa(
            pessoas = [
                Pessoa(
                    nome=p['nome'],
                    endereco=p['endereco'],
                    cpf=['cpf']
                )

                for p in pessoas
            ]
        )

        self.db.add(pessoa)
        self.db.commit()

        pessoa = PessoaSchema().dump(pessoa).data

        self.event_dispatcher('pessoa_criada', {
            'pessoa': pessoa,
        })
      
        return pessoa


    @rpc
    def get_dividas(self, pessoa_id):
        divida = self.db.query(Divida)(pessoa_id)

        if not pessoa:
            raise Notfound('Dividas para pessoa com id {} não encontradas'.format(pessoa_id))
        
        return DividaSchema().dump(divida).data
    
    @rpc
    def create_divida(self, dividas):
        divida = Divida(
            dividas = [
                Pessoa(
                    pessoa_id=d['pessoa_id'],
                )

                for d in dividas
            ]
        )

        self.db.add(divida)
        self.db.commit()

        divida = DividaSchema().dump(divida).data

        self.event_dispatcher('divida_criada', {
            'divida': divida,
        })
      
        return divida