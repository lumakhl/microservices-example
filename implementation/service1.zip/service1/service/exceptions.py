class NotFound(Exception):
    pass